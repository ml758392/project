#define NARROW_WRAPPER
#include "config.h"
#undef WIDECHAR
#define NARROWCHAR
#include "./history.c"
